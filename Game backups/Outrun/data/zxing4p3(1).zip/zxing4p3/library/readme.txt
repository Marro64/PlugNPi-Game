Adjust the following ENV vars for compiling libs with JDK1.5

C:\Program Files\Java\jre6\bin;C:\Program Files\Java\jdk1.6.0_13\bin;C:\oracle\ora8i\bin;C:\WINDOWS\system32;C:\WINDOWS;C:\WINDOWS\System32\Wbem;C:\Program Files\Common Files\Adaptec Shared\System;C:\Program Files\UltraEdit;C:\Program Files\QuickTime\QTSystem\;C:\Program Files\OpenCV\bin

.;C:\Program Files\Java\jre6\lib\ext\QTJava.zip

C:\Program Files\Java\jdk1.6.0_13

C:\Program Files\Java\jre6\bin;C:\Program Files\Java\jdk1.6.0_13\bin;C:\oracle\ora8i\bin;C:\WINDOWS\system32;C:\WINDOWS;C:\WINDOWS\System32\Wbem;C:\Program Files\Common Files\Adaptec Shared\System;C:\Program Files\OpenCV\bin;C:\Program Files\QuickTime\QTSystem\;C:\ant\bin;C:\Program Files\Android\android-sdk-windows\tools

C:\Program Files\Java\jre6\lib\ext\QTJava.zip

----

C:\Program Files\Java\jre6\bin;C:\Program Files\Java\jdk1.5.0_22\bin;C:\WINDOWS\system32;C:\WINDOWS;C:\WINDOWS\System32\Wbem;C:\Program Files\Common Files\Adaptec Shared\System;C:\Program Files\UltraEdit;C:\Program Files\QuickTime\QTSystem\;C:\Program Files\OpenCV\bin

C:\Program Files\Java\jdk1.5.0_22

C:\Program Files\Java\jre1.5.0_22\bin;C:\Program Files\Java\jdk1.5.0_22\bin;C:\WINDOWS\system32;C:\WINDOWS;C:\WINDOWS\System32\Wbem;C:\Program Files\Common Files\Adaptec Shared\System;C:\Program Files\OpenCV\bin;C:\Program Files\QuickTime\QTSystem\;C:\ant\bin;C:\Program Files\Android\android-sdk-windows\tools

